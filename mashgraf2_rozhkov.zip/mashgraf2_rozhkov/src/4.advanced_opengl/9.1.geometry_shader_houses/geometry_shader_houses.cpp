#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb_image.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnopengl/filesystem.h>
#include <learnopengl/shader.h>
#include <learnopengl/camera.h>
#include <learnopengl/model.h>
#include <learnopengl/shader_m.h>

#include <iostream>

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow *window);
float rocket_fly();

unsigned int loadTexture(const char *path);
unsigned int loadCubemap(vector<std::string> faces);

//Размер окна
const unsigned int SCR_WIDTH = 1920;
const unsigned int SCR_HEIGHT = 1080;


float cam_x=0.0f;
float cam_y=0.0f;
float cam_z=1.5f;


Camera camera(glm::vec3(0.0f, 0.0f, 1.5f));
float lastX = (float)SCR_WIDTH / 2.0;
float lastY = (float)SCR_HEIGHT / 2.0;
bool firstMouse = true;

float deltaTime = 0.0f;
float lastFrame = 0.0f;



float Left = 0.0f;
float Right = 0.0f;
float Forward = 0.0f;
float Backward = 0.0f;
float z=0.0f;


int main()
{
    // Инициализация и установка конфигурации glfw
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);//только для os X
#endif

    //Создание окна
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Rozhkov Nikita 324", NULL, NULL);
    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    
    //Для управления мышкой
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    
    
    // Проверка все ли функции glad загружены
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    glEnable(GL_DEPTH_TEST);

    
    /*привязка к шейдерам */
    
    Shader shader_cub("6.2.cubemaps.vs", "6.2.cubemaps.fs");
    
    Shader shader("9.1.geometry_shader.vs", "9.1.geometry_shader.fs", "9.1.geometry_shader.gs");
    
    Shader skyboxShader("6.2.skybox.vs", "6.2.skybox.fs");
    
    Shader ourShader("1.model_loading.vs", "1.model_loading.fs");
    
    Shader ourShader2("1.model_loading.vs", "1.model_loading.fs");
       
    Shader ourShader3("1.model_loading.vs", "1.model_loading.fs");
    
    Shader ourShader4("1.model_loading.vs", "1.model_loading.fs");
    
    Shader ourShader5("1.model_loading.vs", "1.model_loading.fs");
    
    
    /*Загрузка модулей*/
    Model ourModel3(FileSystem::getPath("resources/objects/obj3/10491_Bowling Ball_v1_max8_iteration-2.obj"));
    Model ourModel2(FileSystem::getPath("resources/objects/obj1/12221_Cat_v1_l3.obj"));
    Model ourModel(FileSystem::getPath("resources/objects/obj2/12228_Dog_v1_L2.obj"));
    Model ourModel4(FileSystem::getPath("resources/objects/obj4/10475_Rocket_Ship_v1_L3.obj"));
    Model ourModel5(FileSystem::getPath("resources/objects/obj4/10475_Rocket_Ship_v1_L3.obj"));
    Model ourModel6(FileSystem::getPath("resources/objects/obj5/10525_Rugby_Ball_v1_L3.obj"));
    
    
    //координаты из LearnOpengl
    float cubeVertices[] = {
        // positions          // normals
        -0.05f, -0.05f, -0.05f,  0.0f,  0.0f, -1.0f,
         0.05f, -0.05f, -0.05f,  0.0f,  0.0f, -1.0f,
         0.05f,  0.05f, -0.05f,  0.0f,  0.0f, -1.0f,
         0.05f,  0.05f, -0.05f,  0.0f,  0.0f, -1.0f,
        -0.05f,  0.05f, -0.05f,  0.0f,  0.0f, -1.0f,
        -0.05f, -0.05f, -0.05f,  0.0f,  0.0f, -1.0f,

        -0.05f, -0.05f,  0.05f,  0.0f,  0.0f, 1.0f,
         0.05f, -0.05f,  0.05f,  0.0f,  0.0f, 1.0f,
         0.05f,  0.05f,  0.05f,  0.0f,  0.0f, 1.0f,
         0.05f,  0.05f,  0.05f,  0.0f,  0.0f, 1.0f,
        -0.05f,  0.05f,  0.05f,  0.0f,  0.0f, 1.0f,
        -0.05f, -0.05f,  0.05f,  0.0f,  0.0f, 1.0f,

        -0.05f,  0.05f,  0.05f, -1.0f,  0.0f,  0.0f,
        -0.05f,  0.05f, -0.05f, -1.0f,  0.0f,  0.0f,
        -0.05f, -0.05f, -0.05f, -1.0f,  0.0f,  0.0f,
        -0.05f, -0.05f, -0.05f, -1.0f,  0.0f,  0.0f,
        -0.05f, -0.05f,  0.05f, -1.0f,  0.0f,  0.0f,
        -0.05f,  0.05f,  0.05f, -1.0f,  0.0f,  0.0f,

         0.05f,  0.05f,  0.05f,  1.0f,  0.0f,  0.0f,
         0.05f,  0.05f, -0.05f,  1.0f,  0.0f,  0.0f,
         0.05f, -0.05f, -0.05f,  1.0f,  0.0f,  0.0f,
         0.05f, -0.05f, -0.05f,  1.0f,  0.0f,  0.0f,
         0.05f, -0.05f,  0.05f,  1.0f,  0.0f,  0.0f,
         0.05f,  0.05f,  0.05f,  1.0f,  0.0f,  0.0f,

        -0.05f, -0.05f, -0.05f,  0.0f, -1.0f,  0.0f,
         0.05f, -0.05f, -0.05f,  0.0f, -1.0f,  0.0f,
         0.05f, -0.05f,  0.05f,  0.0f, -1.0f,  0.0f,
         0.05f, -0.05f,  0.05f,  0.0f, -1.0f,  0.0f,
        -0.05f, -0.05f,  0.05f,  0.0f, -1.0f,  0.0f,
        -0.05f, -0.05f, -0.05f,  0.0f, -1.0f,  0.0f,

        -0.05f,  0.05f, -0.05f,  0.0f,  1.0f,  0.0f,
         0.05f,  0.05f, -0.05f,  0.0f,  1.0f,  0.0f,
         0.05f,  0.05f,  0.05f,  0.0f,  1.0f,  0.0f,
         0.05f,  0.05f,  0.05f,  0.0f,  1.0f,  0.0f,
        -0.05f,  0.05f,  0.05f,  0.0f,  1.0f,  0.0f,
        -0.05f,  0.05f, -0.05f,  0.0f,  1.0f,  0.0f
    };
    
    //координаты паралелограмов
    float points[] = {
        -0.5f,  0.5f, 1.0f, 0.0f, 0.0f, 
         0.5f,  0.5f, 0.0f, 1.0f, 0.0f, 
         0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 
        -0.5f, -0.5f, 1.0f, 1.0f, 0.0f  
    };
    float skyboxVertices[] = {
        // Точки для прикрепления skybox
        -1.0f,  1.0f, -1.0f,
        -1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,

        -1.0f, -1.0f,  1.0f,
        -1.0f, -1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f, -1.0f,
        -1.0f,  1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,

         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,

        -1.0f, -1.0f,  1.0f,
        -1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f, -1.0f,  1.0f,
        -1.0f, -1.0f,  1.0f,

        -1.0f,  1.0f, -1.0f,
         1.0f,  1.0f, -1.0f,
         1.0f,  1.0f,  1.0f,
         1.0f,  1.0f,  1.0f,
        -1.0f,  1.0f,  1.0f,
        -1.0f,  1.0f, -1.0f,

        -1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f, -1.0f,
         1.0f, -1.0f, -1.0f,
        -1.0f, -1.0f,  1.0f,
         1.0f, -1.0f,  1.0f
    };
    
    unsigned int VBO, VAO;
    glGenBuffers(1, &VBO);
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points), &points, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), 0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(2 * sizeof(float)));
    glBindVertexArray(0);
    
    
    unsigned int cubeVAO, cubeVBO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &cubeVBO);
    glBindVertexArray(cubeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), &cubeVertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    
    
    
    unsigned int skyboxVAO, skyboxVBO;
    glGenVertexArrays(1, &skyboxVAO);
    glGenBuffers(1, &skyboxVBO);
    glBindVertexArray(skyboxVAO);
    glBindBuffer(GL_ARRAY_BUFFER, skyboxVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(skyboxVertices), &skyboxVertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

    //Загрузка текстур
    vector<std::string> faces
    {
        
        FileSystem::getPath("resources/textures/skybox/right.jpg"),
        FileSystem::getPath("resources/textures/skybox/left.jpg"),
        FileSystem::getPath("resources/textures/skybox/top.jpg"),
        FileSystem::getPath("resources/textures/skybox/bottom.jpg"),
        FileSystem::getPath("resources/textures/skybox/front.jpg"),
        FileSystem::getPath("resources/textures/skybox/back.jpg")
        
    };
    unsigned int cubemapTexture = loadCubemap(faces);

    
    
    //Запуск шейдеров
    shader_cub.use();
    shader_cub.setInt("skybox", 0);
    skyboxShader.use();
    skyboxShader.setInt("skybox", 0);

    //цикл пока нужно отрисовывать картинку (в нашем случае до нажатия esc)
    while (!glfwWindowShouldClose(window))
    {
        //Для положения объектов изменяющих положение со временем
        float currentFrame = glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;
        
        
        
        
        processInput(window);
        
        glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);



        
        shader_cub.use();
        glm::mat4 model = glm::mat4(1.0f);
        model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(0.0, 1.0, 0.0));
        glm::mat4 view = camera.GetViewMatrix();
        glm::mat4 projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        shader_cub.setMat4("model", model);
        shader_cub.setMat4("view", view);
        shader_cub.setMat4("projection", projection);
        shader_cub.setVec3("cameraPos", camera.Position);
        
        
        
        //Куб
        glBindVertexArray(cubeVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
        glDrawArrays(GL_TRIANGLES, 0, 36);
        glBindVertexArray(0);

        
        glDepthFunc(GL_LEQUAL);  
        skyboxShader.use();
        view = glm::mat4(glm::mat3(camera.GetViewMatrix()));
        skyboxShader.setMat4("view", view);
        skyboxShader.setMat4("projection", projection);
        
        
        // skybox
        glBindVertexArray(skyboxVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
        glDrawArrays(GL_TRIANGLES, 0, 36);
        glBindVertexArray(0);
        glDepthFunc(GL_LESS); 

        
        

        
        shader.use();
        model = glm::mat4(1.0f);
        model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(0.5f, 1.0f, 0.0f));
        view = camera.GetViewMatrix();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        shader.setMat4("model", model);
        shader.setMat4("view", view);
        shader.setMat4("projection", projection);
        shader.setVec3("cameraPos", camera.Position);
        glBindVertexArray(VAO);
        glDrawArrays(GL_POINTS, 0, 4);
        glBindVertexArray(0);
        
        
        
        
        
    
        
        ourShader.use();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = camera.GetViewMatrix();
        ourShader.setMat4("projection", projection);
        ourShader.setMat4("view", view);



        model = glm::mat4(1.0f);
        
        model = glm::translate(model, glm::vec3(0.4f, 0.0f, 0.0f)); //перемещение
        
        model = glm::scale(model, glm::vec3(0.005f, 0.005f, 0.005f));//уменьшение
        model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(1.0, 0.0, 0.0));//поворот со временем
        ourShader.setMat4("model", model);
        ourModel.Draw(ourShader);
        
        
        ourShader2.use();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = camera.GetViewMatrix();
        ourShader2.setMat4("projection", projection);
        ourShader2.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(-0.4f, 0.0f, 0.0f));         
        model = glm::scale(model, glm::vec3(0.005f, 0.005f, 0.005f));
        model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(1.0, 0.0, 0.0));
        ourShader2.setMat4("model", model);
        ourModel2.Draw(ourShader2);
        
        
        
        ourShader3.use();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = camera.GetViewMatrix();
        ourShader3.setMat4("projection", projection);
        ourShader3.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(Right+Left, 0.2f, Forward+Backward));
        model = glm::scale(model, glm::vec3(0.005f, 0.005f, 0.005f));
        ourShader3.setMat4("model", model);
        ourModel3.Draw(ourShader3);
        
        
        
        ourShader4.use();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = camera.GetViewMatrix();
        ourShader4.setMat4("projection", projection);
        ourShader4.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0, 0.4f, rocket_fly()));
        model = glm::scale(model, glm::vec3(0.0008f, 0.0008f, 0.0008f));
        ourShader4.setMat4("model", model);
        ourModel4.Draw(ourShader4);
        
        
        
        ourShader5.use();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = camera.GetViewMatrix();
        ourShader5.setMat4("projection", projection);
        ourShader5.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(rocket_fly(), -0.4f, 0.0));
        model = glm::rotate(model, (float)(2*glfwGetTime()), glm::vec3(1.0,0.0,0.0));
        model = glm::rotate(model, (float)(3.14f*0.5f), glm::vec3(0.0, 1.0, 0.0));
        model = glm::scale(model, glm::vec3(0.0008f, 0.0008f, 0.0008f));
        ourShader5.setMat4("model", model);
        ourModel5.Draw(ourShader5);
        
        
        
        
        ourShader5.use();
        projection = glm::perspective(glm::radians(camera.Zoom), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
        view = camera.GetViewMatrix();
        ourShader5.setMat4("projection", projection);
        ourShader5.setMat4("view", view);
        model = glm::mat4(1.0f);
        model = glm::translate(model, glm::vec3(0.0,-0.2,0.0));
        model = glm::rotate(model, (float)glfwGetTime(), glm::vec3(-1.0, 0.0, 0.0));
        model = glm::scale(model, glm::vec3(0.004f, 0.004f, 0.004f));
        ourShader5.setMat4("model", model);
        ourModel6.Draw(ourShader5);
        
        
        
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    //удаление всех картинок и закрытие окна
    glDeleteVertexArrays(1, &VAO);
    glDeleteVertexArrays(1, &skyboxVAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &skyboxVAO);

    glfwTerminate();
    return 0;
}

//отлавливание нажатий клавиш
void processInput(GLFWwindow *window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);



    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        camera.ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        camera.ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        camera.ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        camera.ProcessKeyboard(RIGHT, deltaTime);
        
        
        
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        Forward-=deltaTime;
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        Backward+=deltaTime;
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        Left-=deltaTime;
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        Right+=deltaTime;
}        
        
        
    

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

//Для управления мышкой
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }

    float xoffset = xpos - lastX;
    float yoffset = lastY - ypos;

    lastX = xpos;
    lastY = ypos;

    camera.ProcessMouseMovement(xoffset, yoffset);
}


void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    camera.ProcessMouseScroll(yoffset);
}

//функция загрузки текстур 
unsigned int loadTexture(char const * path)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);

    int width, height, nrComponents;
    unsigned char *data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data)
    {
        GLenum format;
        if (nrComponents == 1)
            format = GL_RED;
        else if (nrComponents == 3)
            format = GL_RGB;
        else if (nrComponents == 4)
            format = GL_RGBA;

        glBindTexture(GL_TEXTURE_2D, textureID);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else
    {
        std::cout << "Texture failed to load at path: " << path << std::endl;
        stbi_image_free(data);
    }

    return textureID;
}


unsigned int loadCubemap(vector<std::string> faces)
{
    unsigned int textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_CUBE_MAP, textureID);

    int width, height, nrChannels;
    for (unsigned int i = 0; i < faces.size(); i++)
    {
        unsigned char *data = stbi_load(faces[i].c_str(), &width, &height, &nrChannels, 0);
        if (data)
        {
            glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
            stbi_image_free(data);
        }
        else
        {
            std::cout << "Cubemap texture failed to load at path: " << faces[i] << std::endl;
            stbi_image_free(data);
        }
    }
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);

    return textureID;
}

//для полета ракеты изменение позиции со временем
float rocket_fly()
{
    
    if (z<2)
        z+=deltaTime;
    else
        z=-2.0f;
    return z;
}
